PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_user` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_discord_id` text(25) NOT NULL,
	`in_game_name` text(64) NOT NULL,
	`server` text(64) NOT NULL,
	`rank` text NOT NULL,
	`alliance` text(64) NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
	`updated_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_user`("id", "user_discord_id", "in_game_name", "server", "rank", "alliance", "status", "created_at", "updated_at") SELECT "id", "user_discord_id", "in_game_name", "server", "rank", "alliance", "status", "created_at", "updated_at" FROM `user`;--> statement-breakpoint
DROP TABLE `user`;--> statement-breakpoint
ALTER TABLE `__new_user` RENAME TO `user`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE UNIQUE INDEX `user_user_discord_id_unique` ON `user` (`user_discord_id`);