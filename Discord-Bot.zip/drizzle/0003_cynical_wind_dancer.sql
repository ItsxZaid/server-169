CREATE TABLE `events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text(255) NOT NULL,
	`description` text NOT NULL,
	`type` text NOT NULL,
	`alliance_target` text(64),
	`event_time` text NOT NULL,
	`created_by_discord_id` text(25) NOT NULL,
	`image_url` text,
	`reminder_sent` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
	`updated_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
	FOREIGN KEY (`created_by_discord_id`) REFERENCES `user`(`user_discord_id`) ON UPDATE no action ON DELETE no action
);
