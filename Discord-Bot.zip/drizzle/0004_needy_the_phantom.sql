CREATE TABLE `buff_bookings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`buff_type` text NOT NULL,
	`slot_time` text NOT NULL,
	`booked_by_discord_id` text(25) NOT NULL,
	`giver_discord_id` text(25),
	`notification_sent` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
	FOREIGN KEY (`booked_by_discord_id`) REFERENCES `user`(`user_discord_id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`giver_discord_id`) REFERENCES `user`(`user_discord_id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `buff_bookings_slot_time_unique` ON `buff_bookings` (`slot_time`);