CREATE TABLE `user` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_discord_id` text(25) NOT NULL,
	`server` integer DEFAULT 169 NOT NULL,
	`rank` text NOT NULL,
	`alliance` text(64) NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`created_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL,
	`updated_at` text DEFAULT 'CURRENT_TIMESTAMP' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `user_user_discord_id_unique` ON `user` (`user_discord_id`);